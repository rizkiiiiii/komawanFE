const path = require('path');
// Add the project's node_modules to the module resolution
module.paths.push(path.join('d:', 'projects', 'file-manager', 'node_modules'));

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://sbekvptmcbhwsyvlqwfz.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNiZWt2cHRtY2Jod3N5dmxxd2Z6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyMjM1MTAsImV4cCI6MjA5Njc5OTUxMH0.LtMUq9L3WB-5VYArEPIPVEdIzWwixDdziJiYi9aikcQ'
);

async function main() {
  console.log('=== SUPABASE TEST ===\n');

  // 1. Login
  console.log('1. Login...');
  const { data: auth, error: authErr } = await supabase.auth.signInWithPassword({
    email: 'syawkat.baihaqi02@gmail.com',
    password: '123321'
  });
  if (authErr) { console.log('LOGIN FAIL:', authErr.message); return; }
  const user = auth.user;
  console.log('   OK user:', user.id);

  // 2. List root
  console.log('\n2. List root...');
  const { data: root, error: rootErr } = await supabase.storage.from('files').list(user.id);
  if (rootErr) { console.log('LIST ERR:', rootErr.message); }
  else {
    console.log('   Root items:', root.length);
    root.forEach(function(f) {
      var info = f.metadata ? '(' + f.metadata.size + 'B)' : '(FOLDER)';
      console.log('   -', f.name, info);
    });
  }

  // 3. List subfolders
  console.log('\n3. List subfolders...');
  var folders = root ? root.filter(function(f) { return !f.metadata && f.name !== '.emptyFolderPlaceholder'; }) : [];
  for (var i = 0; i < folders.length; i++) {
    var fo = folders[i];
    var folderPath = user.id + '/' + fo.name;
    var res = await supabase.storage.from('files').list(folderPath);
    console.log('   Folder "' + fo.name + '":', res.data ? res.data.length : 0, 'files');
    if (res.data) {
      res.data.forEach(function(f) {
        var info = f.metadata ? '(' + f.metadata.size + 'B)' : '';
        console.log('     -', f.name, info);
      });
    }
  }

  // 4. Test delete - upload then delete
  console.log('\n4. Test DELETE capability...');
  var testPath = user.id + '/__test_' + Date.now() + '.txt';
  var upRes = await supabase.storage.from('files').upload(testPath, Buffer.from('test delete'));
  if (upRes.error) {
    console.log('   UPLOAD FAIL:', upRes.error.message);
  } else {
    console.log('   Upload OK:', testPath);
    var delRes = await supabase.storage.from('files').remove([testPath]);
    if (delRes.error) {
      console.log('   DELETE FAIL:', delRes.error.message);
      console.log('   >>> RLS POLICY ISSUE! Need to add DELETE policy in Supabase Dashboard!');
    } else {
      console.log('   DELETE OK:', JSON.stringify(delRes.data));
    }
  }

  // 5. Test share
  console.log('\n5. Test SHARE...');
  if (root) {
    var fileItem = root.find(function(f) { return f.metadata; });
    if (fileItem) {
      var shareRes = await supabase.storage.from('files').createSignedUrl(user.id + '/' + fileItem.name, 3600);
      if (shareRes.error) {
        console.log('   SHARE FAIL:', shareRes.error.message);
      } else {
        console.log('   SHARE OK: URL generated successfully');
      }
    } else {
      console.log('   No file in root to test share');
    }
  }

  await supabase.auth.signOut();
  console.log('\n=== DONE ===');
}

main().catch(function(e) { console.error('ERROR:', e); });
